airportdict={
"Amritsar-Sri Guru Ram Dass Jee International Airport":"ATQ",
"Bengaluru-Kempegowda International Airport":"BLR",
"Calicut International Airport":"CCJ",
"Chennai International Airport":"MAA",
"Hyderabad-Rajiv Gandhi International Airport":"HYD",
"Cochin International Airport":"COK",
"Kolkata-Netaji Subhash Chandra Bose International Airport":"CCU",
"Mumbai International Airport":"BOM",
"Delhi-Indira Gandhi International Airport":"DEL",
"Thiruvananthapuram-Trivandrum International Airport":"TRV",
"Goa-Dabolim Airport":"GOI",
"Indore-Devi Ahilyabai Holkar International Airport":"IDR"
}

conn_str = "mongodb+srv://rkr2137:Rahul%402137@cluster0.dtzxv.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"